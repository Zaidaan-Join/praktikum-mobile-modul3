import { useEffect } from 'react';
import { Stack, useRouter, useSegments } from 'expo-router';
import { AuthProvider, useAuth } from '../context/AuthContext';

function Navigator() {
    const { token, loading } = useAuth();
    const segments = useSegments();
    const router = useRouter();

    useEffect(() => {
        if (loading) return;

        // Mengecek apakah pengguna sedang mencoba mengakses halaman di dalam folder (app)
        const inAppGroup = segments[0] === '(app)';

        if (!token && inAppGroup) {
            // Jika tidak punya token tapi mencoba masuk ke area privat, tendang ke login
            router.replace('/sign-in');
        } else if (token && !inAppGroup) {
            // Jika sudah punya token (sudah login) tapi masih di halaman publik, tarik ke beranda
            router.replace('/(app)');
        }
    }, [token, loading, segments]);

    if (loading) return null;

    return (
        <Stack screenOptions={{ headerShown: false }}>
            <Stack.Screen name="sign-in" options={{ title: 'Login', headerShown: true }} />
            <Stack.Screen name="register" options={{ title: 'Daftar', headerShown: true }} />
            <Stack.Screen name="(app)" />
        </Stack>
    );
}

export default function RootLayout() {
    return (
        <AuthProvider>
            <Navigator />
        </AuthProvider>
    );
}