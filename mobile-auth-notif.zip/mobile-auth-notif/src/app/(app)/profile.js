import { useEffect, useState } from 'react';
import { View, Text, ActivityIndicator, StyleSheet } from 'react-native';
import { useAuth } from '../../context/AuthContext';
import { getMe } from '../../services/authService';

export default function ProfileScreen() {
    const { token } = useAuth();
    const [profile, setProfile] = useState(null);

    useEffect(() => {
        getMe(token).then(setProfile).catch(console.error);
    }, [token]);

    if (!profile) return <ActivityIndicator style={{ flex: 1, justifyContent: 'center' }} />;

    return (
        <View style={styles.container}>
            <Text style={styles.title}>Profil Pengguna</Text>
            <Text style={styles.text}>Nama: {profile.nama}</Text>
            <Text style={styles.text}>Email: {profile.email}</Text>
            <Text style={styles.text}>ID: {profile.id}</Text>
        </View>
    );
}

const styles = StyleSheet.create({
    container: { flex: 1, padding: 24, gap: 10, justifyContent: 'center' },
    title: { fontSize: 24, fontWeight: 'bold', marginBottom: 10 },
    text: { fontSize: 16 }
});