import { useEffect, useState } from 'react';
import { View, Text, StyleSheet, Button, Platform, Alert } from 'react-native';
import { useAuth } from '../../context/AuthContext';
import { useRouter } from 'expo-router';
import * as Notifications from 'expo-notifications';
import * as Device from 'expo-device';
import Constants from 'expo-constants';

// Konfigurasi agar notifikasi muncul meskipun aplikasi sedang dibuka
Notifications.setNotificationHandler({
    handleNotification: async () => ({
        shouldShowAlert: true,
        shouldPlaySound: true,
        shouldSetBadge: false,
    }),
});

export default function HomeScreen() {
    const { token, signOut } = useAuth();
    const router = useRouter();
    const [expoPushToken, setExpoPushToken] = useState('');

    useEffect(() => {
        // Hanya jalankan proses jika 'token' JWT sudah berhasil didapatkan dari state/storage
        if (token) {
            registerForPushNotificationsAsync().then(pushToken => {
                if (pushToken) {
                    setExpoPushToken(pushToken);
                    sendTokenToBackend(pushToken);
                }
            });
        }
    }, [token]);

    // Fungsi untuk meminta izin dan mendapatkan token unik HP
    async function registerForPushNotificationsAsync() {
        let token;
        
        if (Platform.OS === 'android') {
            await Notifications.setNotificationChannelAsync('default', {
                name: 'default',
                importance: Notifications.AndroidImportance.MAX,
                vibrationPattern: [0, 250, 250, 250],
                lightColor: '#FF231F7C',
            });
        }

        if (Device.isDevice) {
            const { status: existingStatus } = await Notifications.getPermissionsAsync();
            let finalStatus = existingStatus;
            
            if (existingStatus !== 'granted') {
                const { status } = await Notifications.requestPermissionsAsync();
                finalStatus = status;
            }
            
            if (finalStatus !== 'granted') {
                Alert.alert('Gagal', 'Izin notifikasi tidak diberikan!');
                return;
            }
            
            // Mengambil ID Proyek EAS secara otomatis
            const projectId = Constants.expoConfig?.extra?.eas?.projectId ?? Constants.easConfig?.projectId;
            
            try {
                token = (await Notifications.getExpoPushTokenAsync({ projectId })).data;
                console.log("Token didapatkan:", token);
            } catch (e) {
                console.error("Gagal mendapatkan push token:", e);
            }
        } else {
            Alert.alert('Peringatan', 'Gunakan perangkat fisik untuk menguji Push Notification');
        }

        return token;
    }

    // Fungsi mengirim token ke MySQL
async function sendTokenToBackend(pushToken) {
    try {
        // Ganti dengan awalan /auth (tanpa /api)
        const url = 'http://192.168.1.7:3000/auth/save-token'; 
        console.log("Mengirim token ke:", url);

        const response = await fetch(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}` 
            },
            body: JSON.stringify({ push_token: pushToken })
        });

        // Gunakan text() dulu untuk mengecek jika ada eror
        const text = await response.text();
        
        try {
            const data = JSON.parse(text);
            console.log("Respon Backend:", data.pesan);
        } catch (e) {
            console.error("Bukan JSON. Pesan server:", text);
        }

    } catch (error) {
        console.error("Gagal koneksi ke backend:", error);
    }
}

async function triggerNotif() {
    try {
        // Pastikan IP disesuaikan jika berubah
        const url = 'http://192.168.1.7:3000/auth/send-test-notif'; 
        const response = await fetch(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}` 
            }
        });
        const data = await response.json();
        console.log(data.pesan);
        alert("Perintah terkirim ke server!");
    } catch (error) {
        console.error("Gagal menembak API:", error);
    }
}

    return (
        <View style={styles.container}>
            <Text style={styles.title}>Halo, Selamat Datang!</Text>
            <Text style={styles.subtitle}>Aplikasi sudah siap menerima notifikasi.</Text>
            
            {expoPushToken ? (
                <Text style={styles.tokenText}>Token aktif: {expoPushToken.substring(0, 15)}...</Text>
            ) : null}

            <View style={styles.buttonContainer}>
                <Button title="LIHAT PROFIL" onPress={() => router.push('/profile')} />
            </View>
            <View style={styles.buttonContainer}>
                <Button 
                    title="KIRIM NOTIFIKASI TEST" 
                    color="green" 
                    onPress={triggerNotif} 
                />
                
                <View style={{ height: 10 }} />
    
                <Button 
                    title="LOGOUT" 
                    color="red" 
                    onPress={async () => {
                        try {
                            await signOut(); 
                        } catch (error) {
                            console.error("Gagal keluar:", error);
                        }
                    }} 
                />
            </View>
        </View>
    );
}

const styles = StyleSheet.create({
    container: { flex: 1, padding: 24, justifyContent: 'center', alignItems: 'center' },
    title: { fontSize: 24, fontWeight: 'bold', marginBottom: 10 },
    subtitle: { fontSize: 16, marginBottom: 20 },
    tokenText: { fontSize: 12, color: 'green', marginBottom: 20 },
    buttonContainer: { width: '100%', marginBottom: 10 }
});